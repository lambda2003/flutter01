import 'dart:typed_data';

class Place {
  int? seq;             // 자동 증가 Primary Key
  String name;          // 식당 명
  String phone;         // 식당 전화번호
  double lat;           // 식당 위치 - 위도
  double lng;           // 식당 위치 - 경도
  Uint8List image;      // 음식 이미지
  String estimate;      // 음식 평가 글
  String? initdate;     // 입력 일자 

  Place(
    {
      this.seq,
      required this.name,
      required this.phone,
      required this.lat,
      required this.lng,
      required this.image,
      required this.estimate,
      this.initdate
    }
  );

  Place.fromMap(Map<String, dynamic> res)
  : seq = res['seq'],
    name = res['name'],
    phone = res['phone'],
    lat = res['lat'],
    lng = res['lng'],
    image = res['image'],
    estimate = res['estimate'],
    initdate = res['initdate'];

}