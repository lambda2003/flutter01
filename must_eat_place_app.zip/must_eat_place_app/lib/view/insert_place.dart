import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:must_eat_place_app/util/message.dart';
import 'package:must_eat_place_app/model/place.dart';
import 'package:must_eat_place_app/util/pcolor.dart';
import 'package:must_eat_place_app/vm/database_handler.dart';

/*
Description : 입력 화면
  - 1) 시작시 GPS신호 획득(권한 부여후)과 화면 구성을 동시에 진행하고 GPS에서 위도 경도 획득후 화면 재구성 
  - 2) 사용자 입력 Check를 for문으로 구성 
  - 3) 입력 버튼을 누르면 Dialog를 보이고 입력 실행후 전 화면으로 이동 
Date : 2025-12-03
Author : Kenny Hahn
*/
class InsertPlace extends StatefulWidget {
  const InsertPlace({super.key});

  @override
  State<InsertPlace> createState() => _InsertPlaceState();
}

class _InsertPlaceState extends State<InsertPlace> {
  // Property
  late Position currentPosition; // GPS 수신 위치
  late double latData;
  late double longData;

  late DatabaseHandler handler;
  late TextEditingController latController;
  late TextEditingController longController;
  late TextEditingController nameController;
  late TextEditingController phoneController;
  late TextEditingController estimateController;
  XFile? imageFile;

  final ImagePicker picker = ImagePicker();
  Message message = Message(); // snack Bar or Dialog같은 Message를 담은 Class


  @override
  void initState() {
    super.initState();
    latData = 0;
    checkLocationPermission(); // 권한 부여 및 GPS 위치 획득
    
    handler = DatabaseHandler();
    latController = TextEditingController();
    longController = TextEditingController();
    nameController = TextEditingController();
    phoneController = TextEditingController();
    estimateController = TextEditingController();

  }

  // 권한 부여
  checkLocationPermission() async {
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.deniedForever) {
      return;
    }

    if (permission == LocationPermission.whileInUse ||
        permission == LocationPermission.always) {
      getCurrentLocation();
    }
  }

  // 위치 
  getCurrentLocation() async {
    // 학원 위치 : 37.4973294 / 127.0293198
    Position position = await Geolocator.getCurrentPosition();
    currentPosition = position;
    latData = currentPosition.latitude;
    longData = currentPosition.longitude;
    // print("lat:$latData, long:$longData");

    latController.text = latData.toString();
    longController.text = longData.toString();

    setState(() {}); // 화면이 먼저 구성되었을 수 있으므로 실행하여야 변경됨 
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(), // KeyBoard 내리기 
      child: Scaffold(
        backgroundColor: PColor.baseBackgroundColor,
        appBar: AppBar(
          title: Text('맛집 추가'),
          centerTitle: true,
          foregroundColor: PColor.appBarForegroundColor,
          backgroundColor: PColor.appBarBackgroundColor,
        ),
        body: latData == 0 // GPS 수신 전
        ? Center(
          child: CircularProgressIndicator(),
          )
        :  Padding(
          padding: const EdgeInsets.all(30.0),
          child: SingleChildScrollView(
            child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ElevatedButton(
                        onPressed: () => getImageFromGallery(ImageSource.gallery),
                        child: Text('이미지 가져오기'),
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      height: 200,
                      color: Colors.grey,
                      child: Center(
                        child: imageFile == null
                            ? const Text('Image is not selected!')
                            : Image.file(File(imageFile!.path)),
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: SizedBox(
                            width: 150,
                            child: TextField(
                              controller: latController,
                              decoration: InputDecoration(
                                labelText: '위도',
                              ),
                              readOnly: true,
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: SizedBox(
                            width: 150,
                            child: TextField(
                              controller: longController,
                              decoration: InputDecoration(
                                labelText: '경도',
                              ),
                              readOnly: true,
                            ),
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TextField(
                        controller: nameController,
                        decoration: InputDecoration(
                          labelText: '이름',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TextField(
                        controller: phoneController,
                        decoration: InputDecoration(
                          labelText: '전화번호',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TextField(
                        controller: estimateController,
                        decoration: InputDecoration(
                          labelText: '평가',
                          border: OutlineInputBorder(),
                        ),
                        maxLength: 50,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.amber,
                          foregroundColor: Colors.white,
                          minimumSize: Size(200, 50)
                        ),
                        onPressed: () => insertAction(), 
                        child: Text('입력'),
                      ),
                    ),
                  ],
                ),
              ),
          ),
        ),
      ),
    );
  } // build

  // ---- Functions ----
  Future getImageFromGallery(ImageSource imageSource) async {
    final XFile? pickedFile = await picker.pickImage(source: imageSource);
    if (pickedFile == null) {
      return;
    } else {
      imageFile = XFile(pickedFile.path);
      setState(() {});
    }
  } // getImageFromGallery

  insertAction() async{
    int result = checkData(); 
    if(result == 0){ // 모두 입력 되었을 경우에만 입력 하기 
      // File Type을 Byte Type으로 변환하기
      File imageFile1 = File(imageFile!.path);
      Uint8List getImage = await imageFile1.readAsBytes();

      var place = Place(
        name: nameController.text.trim(), 
        phone: phoneController.text.trim(), 
        lat: latData, 
        lng: longData, 
        image: getImage, 
        estimate: estimateController.text.trim());

      result = await handler.insertPlace(place);
      result == 0
      ? message.snackBar('DB 오류', 'Data저장시 문제가 발생했습니다')
      : message.showDialog('입력 결과', '입력이 완료 되었습니다.');
    }

  } // insertAction

  // 입력 체크 : Error 조건 구성
  int checkData(){
    final List<Map<String, dynamic>> checks = [
      {
        'condition': imageFile == null,
        'title': '이미지',
        'message': '이미지를 선택 하세요',
      },
      {
        'condition': nameController.text.trim().isEmpty,
        'title': '이름',
        'message': '이름을 입력 하세요',
      },
      {
        'condition': phoneController.text.trim().isEmpty,
        'title': '전화번호',
        'message': '전화번호를 입력 하세요',
      },
      {
        'condition': estimateController.text.trim().isEmpty,
        'title': '평가',
        'message': '평가를 입력 하세요',
      },
    ];

    int result = 0;

    for (var check in checks) {
      if (check['condition']) {
        message.snackBar(check['title'], check['message']);
        result++;
      }
    }
    
    return result;
  } // checkData

} // class
