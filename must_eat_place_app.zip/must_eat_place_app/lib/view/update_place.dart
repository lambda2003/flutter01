import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:must_eat_place_app/model/place.dart';
import 'package:must_eat_place_app/util/message.dart';
import 'package:must_eat_place_app/util/pcolor.dart';
import 'package:must_eat_place_app/vm/database_handler.dart';

/*
Description : 수정 화면
  - 1) GPS와 관계가 없고 전화면에서 argument로 넘어온 데이터를 출력 하면 됨
  - 2) 사용자 수정 Check를 for문으로 구성 
  - 3) 수정 버튼을 누르면 Dialog를 보이고 입력 실행후 전 화면으로 이동 
Date : 2025-12-03
Author : Kenny Hahn
*/

class UpdatePlace extends StatefulWidget {
  const UpdatePlace({super.key});

  @override
  State<UpdatePlace> createState() => _UpdatePlaceState();
}

class _UpdatePlaceState extends State<UpdatePlace> {
  // Property
  late DatabaseHandler handler;
  late TextEditingController latController;
  late TextEditingController longController;
  late TextEditingController nameController;
  late TextEditingController phoneController;
  late TextEditingController estimateController;
  XFile? imageFile;
  late int firstDisp; // 이미지를 PhotoAlbum에서 새롭게 받았는지 아니면 기존것 사용하는지 Check

  final ImagePicker picker = ImagePicker();
  Message message = Message(); // snack Bar or Dialog같은 Message를 담은 Class
  var value = Get.arguments ?? "__";

  @override
  void initState() {
    super.initState();
    handler = DatabaseHandler();
    latController = TextEditingController();
    longController = TextEditingController();
    nameController = TextEditingController();
    phoneController = TextEditingController();
    estimateController = TextEditingController();

    nameController.text = value[1];
    phoneController.text = value[2];
    latController.text = value[3].toString();
    longController.text = value[4].toString();
    estimateController.text = value[5];

    firstDisp = 0;
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(), // KeyBoard 내리기 
      child: Scaffold(
        backgroundColor: PColor.baseBackgroundColor,
        appBar: AppBar(
          title: Text('맛집 수정'),
          centerTitle: true,
          foregroundColor: PColor.appBarForegroundColor,
          backgroundColor: PColor.appBarBackgroundColor,
        ),
        body: Padding(
          padding: const EdgeInsets.all(30.0),
          child: SingleChildScrollView(
            child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ElevatedButton(
                        onPressed: () => getImageFromGallery(ImageSource.gallery),
                        child: Text('이미지 가져오기'),
                      ),
                    ),
                    firstDisp == 0
                    ? Container( // 기존 이미지 보이기 : Memory에 있는 Image Data
                      width: MediaQuery.of(context).size.width,
                      height: 200,
                      color: Colors.grey,
                      child: Center(
                        child: Image.memory(value[6]),
                      ),
                    )
                    : Container( // 새로운 이미지 보이기 : Phone의 PhotoAlbum에 있는 이미지 경로 
                      width: MediaQuery.of(context).size.width,
                      height: 200,
                      color: Colors.grey,
                      child: Center(
                        child: imageFile == null
                            ? const Text('Image is not selected!')
                            : Image.file(File(imageFile!.path)),
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: SizedBox(
                            width: 150,
                            child: TextField(
                              controller: latController,
                              decoration: InputDecoration(
                                labelText: '위도',
                              ),
                              readOnly: true,
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: SizedBox(
                            width: 150,
                            child: TextField(
                              controller: longController,
                              decoration: InputDecoration(
                                labelText: '경도',
                              ),
                              readOnly: true,
                            ),
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TextField(
                        controller: nameController,
                        decoration: InputDecoration(
                          labelText: '이름',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TextField(
                        controller: phoneController,
                        decoration: InputDecoration(
                          labelText: '전화번호',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TextField(
                        controller: estimateController,
                        decoration: InputDecoration(
                          labelText: '평가',
                          border: OutlineInputBorder(),
                        ),
                        maxLength: 50,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.amber,
                          foregroundColor: Colors.white,
                          minimumSize: Size(200, 50)
                        ),
                        onPressed: () {
                          firstDisp == 0 // 이미지의 변경 여부 확인 
                          ? updateAction()
                          : updateActionAll();
                        }, 
                        child: Text('수정'),
                      ),
                    ),
                  ],
                ),
              ),
          ),
        ),
      ),
    );
  } // build

  // ---- Functions ----
  Future getImageFromGallery(ImageSource imageSource) async {
    final XFile? pickedFile = await picker.pickImage(source: imageSource);
    if (pickedFile == null) {
      return;
    } else {
      imageFile = XFile(pickedFile.path);
      firstDisp+=1;
      setState(() {});
    }
  } // getImageFromGallery

  // Image 포함 수정
  updateActionAll() async{
    int result = checkData();
    if(result == 0){
      // File Type을 Byte Type으로 변환하기
      File imageFile1 = File(imageFile!.path);
      Uint8List getImage = await imageFile1.readAsBytes();

      var place = Place(
        seq: value[0],
        name: nameController.text.trim(), 
        phone: phoneController.text.trim(), 
        lat: double.parse(latController.text), 
        lng: double.parse(longController.text), 
        image: getImage, 
        estimate: estimateController.text.trim());

      result = await handler.updatePlaceAll(place);
      result == 0
      ? message.snackBar('DB 오류', 'Data 수정시 문제가 발생했습니다')
      : message.showDialog('수정 결과', '수정 완료 되었습니다.');
    }
  } // updateActionAll

  // Image 제외 수정 
  updateAction() async{
    int result = checkData();
    if(result == 0){
      var place = Place(
        seq: value[0],
        name: nameController.text.trim(), 
        phone: phoneController.text.trim(), 
        lat: double.parse(latController.text), 
        lng: double.parse(longController.text), 
        image: value[6], 
        estimate: estimateController.text.trim());

      result = await handler.updatePlace(place);
      result == 0
      ? message.snackBar('DB 오류', 'Data 수정시 문제가 발생했습니다')
      : message.showDialog('수정 결과', '수정 완료 되었습니다.');
    }
  } // updateActionAll

  // 수정 항목 Check
  int checkData(){
    final List<Map<String, dynamic>> checks = [ // Error 조건 구성 
      {
        'condition': imageFile == null && firstDisp > 0,
        'title': '이미지',
        'message': '이미지를 선택 하세요',
      },
      {
        'condition': nameController.text.trim().isEmpty,
        'title': '이름',
        'message': '이름을 입력 하세요',
      },
      {
        'condition': phoneController.text.trim().isEmpty,
        'title': '전화번호',
        'message': '전화번호를 입력 하세요',
      },
      {
        'condition': estimateController.text.trim().isEmpty,
        'title': '평가',
        'message': '평가를 입력 하세요',
      },
    ];

    int result = 0;

    for (var check in checks) {
      if (check['condition']) {
        message.snackBar(check['title'], check['message']);
        result++;
      }
    }
    
    return result;
  } // checkData

} // class
