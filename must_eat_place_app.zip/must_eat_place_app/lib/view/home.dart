import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:get/get.dart';
import 'package:must_eat_place_app/util/pcolor.dart';
import 'package:must_eat_place_app/view/insert_place.dart';
import 'package:must_eat_place_app/view/map_place.dart';
import 'package:must_eat_place_app/view/update_place.dart';
import 'package:must_eat_place_app/vm/database_handler.dart';


/* 
Description : 검색으로 첫화면
  - 1) Table에서 전체 정보를 획득한다.
  - 2) 획득된 정보를 memory에 존재 함으로 snapshot으로 Data를 가져온다.
  - 3) 입력으로 이동후에 돌아왔을 경우 Table을 새로 검색하여 화면을 구성한다.
  - 4) 수정시
      - Slidable에서 수정을 선택하면 선택된 데이터를 Get의 argument로 넘긴다.
      - 돌아왔을 경우 Table을 새로 검색하여 화면을 구성한다.
  - 5) 삭제는 Slidable Action에서 바로 삭제를 하고 화면을 구성한다. 
Date : 2025-12-03
Author : Kenny Hahn
*/
class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  // Property
  late DatabaseHandler handler;

  @override
  void initState() {
    super.initState();
    handler = DatabaseHandler();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: PColor.baseBackgroundColor,
      appBar: AppBar(
        title: Text('내가 경험한 맛집 리스트'),
        backgroundColor: PColor.appBarBackgroundColor,
        foregroundColor: PColor.appBarForegroundColor,
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: () => Get.to(InsertPlace())!.then((value) => reloadData()),
            icon: Icon(Icons.add_outlined),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: FutureBuilder(
          future: handler.queryPlace(),
          builder: (context, snapshot) {
            return snapshot.hasData && snapshot.data!.isNotEmpty
                ? ListView.builder(
                    itemCount: snapshot.data!.length,
                    itemBuilder: (context, index) {
                      return GestureDetector( // Card를 선택 
                        onTap: () => Get.to(
                          MapPlace(),
                          arguments: [
                            snapshot.data![index].lat,
                            snapshot.data![index].lng,
                          ]
                        ),
                        child: Slidable(
                          startActionPane: ActionPane( // Card를 Drag후 수정 선택
                            motion: BehindMotion(), 
                            children: [
                              SlidableAction(
                                backgroundColor: Colors.green,
                                icon: Icons.edit,
                                label: '수정',
                                onPressed: (context) => Get.to(
                                  UpdatePlace(),
                                  arguments: [
                                    snapshot.data![index].seq,
                                    snapshot.data![index].name,
                                    snapshot.data![index].phone,
                                    snapshot.data![index].lat,
                                    snapshot.data![index].lng,
                                    snapshot.data![index].estimate,
                                    snapshot.data![index].image,
                                  ]
                                )!.then((value) => reloadData()),
                              ),
                            ],
                          ),
                          endActionPane: ActionPane( // Card를 Drag후 삭제 선택 
                            motion: BehindMotion(), 
                            children: [
                              SlidableAction(
                                backgroundColor: Colors.red,
                                icon: Icons.delete,
                                label: '삭제',
                                onPressed: (context) async{
                                  await handler.deletePlace(snapshot.data![index].seq!);
                                  setState(() {});
                                },
                              )
                            ],
                          ),
                          child: Card(
                            color: index % 2 == 0 ? const Color.fromARGB(255, 4, 186, 241) : const Color.fromARGB(255, 240, 145, 3),
                            child: Row(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(20),
                                    child: Image.memory(
                                      snapshot.data![index].image, 
                                      width: 70,
                                      height: 70,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(20, 0, 0, 0),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Text(
                                            '식당 명   : ',
                                            style: TextStyle(fontWeight: FontWeight.bold),
                                          ),
                                          Text(snapshot.data![index].name),
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          Text(
                                            '전화번호 : ',
                                            style: TextStyle(fontWeight: FontWeight.bold),
                                          ),
                                          Text(snapshot.data![index].phone),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  )
                : Center(child: Text('등록된 데이터가 없습니다!'));
          },
        ),
      ),
    );
  } // build

  // --- Functions ---
  reloadData(){
    handler.queryPlace();
    setState(() {});
  }


} // class
