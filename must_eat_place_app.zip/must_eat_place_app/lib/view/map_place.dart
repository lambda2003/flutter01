import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:get/get.dart';
import 'package:latlong2/latlong.dart' as latlng;
import 'package:must_eat_place_app/util/pcolor.dart';

/*
Description : 지도 보기
  - 1) 시작시 전화면에서 보내준 위도와 경도로 Map 구성
Date : 2025-12-03
Author : Kenny Hahn
*/

class MapPlace extends StatefulWidget {
  const MapPlace({super.key});

  @override
  State<MapPlace> createState() => _MapPlaceState();
}

class _MapPlaceState extends State<MapPlace> {
  // Property
  late MapController mapController;
  var value = Get.arguments ?? "__";

  @override
  void initState() {
    super.initState();
    mapController = MapController();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('위치 보기'),
        centerTitle: true,
        foregroundColor: PColor.appBarForegroundColor,
        backgroundColor: PColor.appBarBackgroundColor,
      ),
      body: FlutterMap(
        mapController: mapController,
        options: MapOptions(
          initialCenter: latlng.LatLng(value[0], value[1]), // <---------------
          initialZoom: 17.0,
        ),
        children: [
          TileLayer(
            urlTemplate: "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
            userAgentPackageName: 'com.tj.gpsmapapp',
          ),
          MarkerLayer(
            markers: [
              Marker(
                width: 80,
                height: 80,
                point: latlng.LatLng(value[0], value[1]), // <----------------------
                child: Column(
                  children: [Icon(Icons.pin_drop, size: 50, color: Colors.red)],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
