import 'package:must_eat_place_app/model/place.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

/*
Description : SQLite용 Connection, Table Creation & CRUD
*/
class DatabaseHandler {
  /*
  ** Model 내용 
  int? seq;
  String name;
  String phone;
  double lat;
  double lng;
  Uint8List image;
  String estimate;
  String? initdate;

  */

  // Connection 및 Table Creation
  Future<Database> initializeDB() async{
    String path = await getDatabasesPath();
    return openDatabase(
      join(path, 'place.db'),
      onCreate: (db, version) async{
        await db.execute(
          """
          create table musteatplace
          (
            seq integer primary key autoincrement,
            name text,
            phone text,
            lat real,
            lng real,
            image blob,
            estimate text,
            initdate date
          )
          """
        );
      },
      version: 1,
    );
  } // initialDB

  // 입력 : 날짜는 SQLite이 날짜 계산값으로 입력 
  Future<int> insertPlace(Place place) async{
    int result = 0;
    final Database db = await initializeDB();
    result = await db.rawInsert(
      """
      insert into musteatplace
      (name, phone, lat, lng, image, estimate, initdate)
      values
      (?,?,?,?,?,?,date('now'))
      """,
      [place.name, place.phone, place.lat, place.lng, place.image, place.estimate]
    );
    return result;
  } // insertPlace

  // 검색 
  Future<List<Place>> queryPlace() async {
    final Database db = await initializeDB();
    final List<Map<String, Object?>> queryResult =
        await db.rawQuery('select * from musteatplace');
    return queryResult.map((e) => Place.fromMap(e)).toList();
  } // queryPlace

  // 수정 : image 부분 제외로 기존에 입력된 이미지를 그대로 사용하는 경우 
  Future<int> updatePlace(Place place) async{
    int result = 0;
    final Database db = await initializeDB();
    result = await db.rawUpdate(
      """
      update musteatplace
      set name = ?, phone = ?, lat =?, lng = ?, estimate = ?
      where seq = ?
      """,
      [place.name, place.phone, place.lat, place.lng, place.estimate, place.seq]
    );

    return result;
  } // updatePlace

  // 수정 : image 부분 포함으로 PhotoAlbum으로 이미지를 변경 하였을 경우 
  Future<int> updatePlaceAll(Place place) async{
    int result = 0;
    final Database db = await initializeDB();
    result = await db.rawUpdate(
      """
      update musteatplace
      set name = ?, phone = ?, lat =?, lng = ?, estimate = ?, image = ?
      where seq = ?
      """,
      [place.name, place.phone, place.lat, place.lng, place.estimate, place.image, place.seq]
    );

    return result;
  } // updatePlaceAll

  // 삭제 : 삭제는 seq만 있으면 되므로 위의 나머지 기능처럼 객체로 Parameter를 받을 필요는 없다.
  Future deletePlace(int seq) async {
    final Database db = await initializeDB();
    await db.rawDelete('delete from musteatplace where seq = ?', [seq]);
  } // deletePlace

} // class