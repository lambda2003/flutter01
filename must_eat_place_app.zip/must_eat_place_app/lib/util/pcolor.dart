import 'package:flutter/material.dart';

/*
Description : 화면 마다 컬러 값을 동일하게 부여 하기 위해
Date : 2025-12-03
Author : Kenny Hahn 
*/

class PColor{
  static Color baseBackgroundColor = Color.fromARGB(255, 226, 226, 224);    // 바탕 배경 컬러
  static Color appBarBackgroundColor = Colors.black;                        // AppBar 배경 컬러
  static Color appBarForegroundColor = Colors.white;                        // AppBar 글자 컬러


}