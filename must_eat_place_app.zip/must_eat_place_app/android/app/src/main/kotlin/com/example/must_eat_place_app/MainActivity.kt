package com.example.must_eat_place_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
