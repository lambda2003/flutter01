import 'package:path/path.dart';
import 'package:simple_todo_list_app/model/todo_list.dart';
import 'package:sqflite/sqflite.dart';

enum TableName { todolist, todolist_deleted, todolist_alarm }

class DatabaseHandle {
  final int limitNum = 3;

  Future<Database> initDatabase() async {
    String path = await getDatabasesPath();
    return openDatabase(
      join(path, 'todolists.db'),
      onCreate: (db, version) async {
        await db.execute("""
          create table todolist (
            id integer primary key autoincrement,
            title text,
            content text,
            isAlarm integer,
            importance integer not null default 5,
            startDate text,
            endDate text
          )
        """);
        await db.execute("""
          create table todolist_alarm (
            id integer primary key,
            title text,
            content text,
            isAlarm integer,
            importance integer,
            startDate text,
            endDate text
          )
        """);

        await db.execute("""
          create table todolist_deleted (
            id integer primary key,
            title text,
            content text,
            isAlarm integer,
            importance integer,
            startDate text,
            endDate text
          )
        """);
      },
      version: 1,
    );
  }

  Future<List<TodoList>> getTodoList(
    Map<String, dynamic>? kwd,
    TableName tableName,
    int s,
  ) async {
    Database db = await initDatabase();
    List<Map<String, Object?>> queryResults = [];
    if (kwd == null) {
      queryResults = await db.rawQuery(
        """
        select * from ${tableName.name.toString()} order by startDate DESC limit ?,?
      
      """,
        [s, limitNum],
      );

      print('================${queryResults.length}');
    } else {
      if (kwd['id'] != null) {
        queryResults = await db.rawQuery(
          """
          select * from ${tableName.name.toString()} where id=? order by startDate DESC limit ?,?
        """,
          [kwd['id'], s, limitNum],
        );
      } else if (kwd['name'] != null) {
        queryResults = await db.rawQuery(
          """
          select * from ${tableName.name.toString()} where title like ? or content like ? order by startDate DESC limit ?,?
        """,
          ['%${kwd["name"]}%', '%${kwd["name"]}%', s, limitNum],
        );
      } else if (kwd['isAlarm'] != null) {
        queryResults = await db.rawQuery(
          """
        select * from ${tableName.name.toString()} where isAlarm=?  order by startDate DESC limit ?,?
      
      """,
          [kwd['isAlarm'], s, limitNum],
        );
      } else if (kwd['startDate'] != null) {
        queryResults = await db.rawQuery(
          """
        select * from ${tableName.name.toString()} where startDate>=? order by startDate DESC limit ?,?
      
        """,
          [kwd['startDate'], s, limitNum],
        );
      } else if (kwd['importance'] != null) {
        queryResults = await db.rawQuery(
          """
        select * from ${tableName.name.toString()} where importance>5 order by importance DESC,startDate DESC limit ?,?
      
        """,
          [s, limitNum],
        );
      }
    }
    // if(queryResults.length>0)
    return queryResults.map((d) => TodoList.fromJson(d)).toList();
    // else
    //   return [];
  }

  Future<int> insertTodoList(TodoList todolist, TableName tableName) async {
    final Database db = await initDatabase();
    int result = 0;
    if (todolist.isAlarm == 1) {
      result = await db.transaction((tx) async {
        int seq = await tx.rawInsert(
          """
          insert into ${tableName.name}(title,importance,isAlarm,startDate) 
          values (?,?,?,?)
""",
          [
            todolist.title,
            todolist.importance,
            todolist.isAlarm,
            todolist.startDate.toString(),
          ],
        );
        await tx.rawInsert(
          """
      insert into todolist_alarm(id,title,importance,isAlarm,startDate) values (?,?,?,?,?)
""",
          [
            seq,
            todolist.title,
            todolist.importance,
            todolist.isAlarm,
            todolist.startDate.toString(),
          ],
        );

        return seq;
      });
    } else {
      result = await db.rawInsert(
        """
      insert into ${tableName.name}(title,importance,isAlarm,startDate) values (?,?,?,?)
    
""",
        [
          todolist.title,
          todolist.importance,
          todolist.isAlarm,
          todolist.startDate.toString(),
        ],
      );
    }

    // int result = await db.rawInsert(
    //   """
    //   insert into ${tableName.name}(title,importance,isAlarm,startDate) values (?,?,?,?)

    // """,
    //   [
    //     todolist.title,
    //     todolist.importance,
    //     todolist.isAlarm,
    //     todolist.startDate.toString(),
    //   ],
    // );
    // if (result != 0 && todolist.isAlarm == 1) {
    //   result = await db.rawInsert(
    //     """
    //   insert into ${tableName.name}(id,title,importance,isAlarm,startDate) values (?,?,?,?,?)

    // """,
    //     [
    //       result,
    //       todolist.title,
    //       todolist.importance,
    //       todolist.isAlarm,
    //       todolist.startDate.toString(),
    //     ],
    //   );
    // }

    return result;
  }

  Future<int> updateTodoList(TodoList todolist, TableName tableName) async {
    Database db = await initDatabase();
    int result = 0;
    if (todolist.isAlarm == 1) {
      result = await db.transaction((tx) async {
        await tx.rawUpdate(
          """
      update ${tableName.name.toString()} set title=?,importance=?,isAlarm=?,startDate=? where id=?
    
    """,
          [
            todolist.title,
            todolist.importance,
            todolist.isAlarm,
            todolist.startDate.toString(),
            todolist.id,
          ],
        );
        await tx.rawUpdate(
          """
      update todolist_alarm set title=?,importance=?,isAlarm=?,startDate=? where id=?
    
    """,
          [
            todolist.title,
            todolist.importance,
            todolist.isAlarm,
            todolist.startDate.toString(),
            todolist.id,
          ],
        );
        return todolist.id!;
      });
    } else {
      result = await db.rawUpdate(
        """
      update ${tableName.name.toString()} set title=?,importance=?,isAlarm=?,startDate=? where id=?
    
    """,
        [
          todolist.title,
          todolist.importance,
          todolist.isAlarm,
          todolist.startDate.toString(),
          todolist.id,
        ],
      );
    }
    return result;
  }

  Future<int> deleteTodoList(int id) async {
    int result = 0;
    try {
      Database db = await initDatabase();

      // Get ID

      List<TodoList> d = await getTodoList({"id": id}, TableName.todolist, 0);

      result = await db.transaction((tx) async {
        await tx.rawDelete("delete from todolist where id=?", [id]);
        await tx.rawInsert(
          "insert into todolist_deleted(id,title,startDate) values (?,?,?)",
          [d[0].id, d[0].title, d[0].startDate.toString()],
        );
        await tx.rawDelete("delete from todolist_alarm where id=?", [id]);
        return 100;
      });

      return result;
    } catch (err) {
      print(err.toString());
      return 0;
    }
  }

  Future<int> deleteAalarm(int id) async {
    Database db = await initDatabase();

    int result = 0;
    result = await db.transaction((tx) async {
      await tx.rawDelete("delete from todolist_alarm where id=?", [id]);
      await tx.rawDelete("update todolist set isAlarm=0 where id=?", [id]);
      return 100;
    });
    return result;
  }
}
